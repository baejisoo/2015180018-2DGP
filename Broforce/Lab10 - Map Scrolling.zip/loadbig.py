from pico2d import *


open_canvas(1280, 1024)
a = load_image('KPU_GROUND_REALLY_BIG.png')
a.draw_now(0,0)
delay(1)
close_canvas()


